- 👋 Hi, I’m @robinbuckley1968
- 👀 I’m interested in stranger things
- 🌱 I’m currently learning algebra at school
- 💞️ I’m looking to collaborate on nothing really
- 📫 How to reach me @robin._,buckley1968 on tiktok
 - my pronouns are she/they
<!---
robinbuckley1968/robinbuckley1968 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
